import pytest
from testpath import modified_env

from jeepney import bus

def test_get_connectable_addresses():
    a = list(bus.get_connectable_addresses('unix:path=/run/user/1000/bus'))
    assert a == ['/run/user/1000/bus']

    a = list(bus.get_connectable_addresses('unix:abstract=/tmp/foo'))
    assert a == ['\0/tmp/foo']

    with pytest.raises(RuntimeError):
        list(bus.get_connectable_addresses("tcp:host=localhost,port=12345"))

    orig = bus.SUPPORTED_TRANSPORTS
    bus.SUPPORTED_TRANSPORTS += ('tcp',)

    a = list(bus.get_connectable_addresses("tcp:host=localhost,port=12345"))
    assert a == [("localhost", 12345)]

    with pytest.raises(RuntimeError):
        list(bus.get_connectable_addresses("tcp:host=example.com,"
                                           "port=12345,"
                                           "family=ipv6"))  # <-

    with pytest.raises(RuntimeError):
        list(bus.get_connectable_addresses("tcp:host=example.com,"
                                           "bind=0.0.0.0,"  # <-
                                           "port=12345"))

    a = list(bus.get_connectable_addresses("tcp:host=example.com,"
                                           "port=12345,"
                                           "family=ipv4"))
    assert a == [("example.com", 12345)]

    with pytest.raises(RuntimeError):
        list(bus.get_connectable_addresses('unix:tmpdir=/tmp'))

    bus.SUPPORTED_TRANSPORTS = orig

def test_get_bus():
    with modified_env({
        'DBUS_SESSION_BUS_ADDRESS': 'unix:path=/run/user/1000/bus',
        'DBUS_SYSTEM_BUS_ADDRESS': 'unix:path=/var/run/dbus/system_bus_socket',
    }):
        assert bus.get_bus('SESSION') == '/run/user/1000/bus'
        assert bus.get_bus('SYSTEM') == '/var/run/dbus/system_bus_socket'

    assert bus.get_bus('unix:path=/run/user/1002/bus') == '/run/user/1002/bus'

    orig = bus.SUPPORTED_TRANSPORTS

    with modified_env({
        'DBUS_SESSION_BUS_ADDRESS': "tcp:host=localhost,port=12345",
        "DBUS_SYSTEM_BUS_ADDRESS": ("tcp:host=example.com,"
                                    "port=12345,family=ipv4"),
    }):
        with pytest.raises(RuntimeError):
            bus.get_bus('SESSION') == ("localhost", 12345)

        bus.SUPPORTED_TRANSPORTS += ('tcp',)

        assert bus.get_bus('SESSION') == ("localhost", 12345)
        assert bus.get_bus("SYSTEM") == ("example.com", 12345)

    assert bus.get_bus("tcp:host=example.com,port=12345") == ("example.com",
                                                              12345)
    bus.SUPPORTED_TRANSPORTS = orig
